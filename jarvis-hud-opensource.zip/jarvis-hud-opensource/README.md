# J.A.R.V.I.S HUD — Open Source Basic Edition

A local, voice-controlled desktop HUD inspired by Iron Man's J.A.R.V.I.S — built with
Electron, React, and a local Python voice pipeline. This basic edition includes:

- **Live weather widget** (via the free Open-Meteo API — no API key needed)
- **Time / date widget**
- **Voice wake word** ("Jarvis") with speech recognition
- **Local AI question answering** via [Ollama](https://ollama.com) — runs entirely on
  your machine, no cloud API keys required
- **Draggable, glass-panel widgets** with a right-click menu to show/hide them
- Full-screen animated "arc reactor" HUD

This is a trimmed-down version for public release. It does not include mini-mode/shrink,
smart home integration, security cameras, calendar sync, or other features from the
original personal build — those depend on private hardware/API setups that don't make
sense to ship generically. Feel free to fork and extend it.

---

## Requirements

- **Node.js** 18 or newer — [nodejs.org](https://nodejs.org)
- **Python** 3.10–3.11 (3.11 recommended; some packages lag behind the newest Python
  releases) — [python.org](https://python.org)
- **Ollama** installed and running locally — [ollama.com](https://ollama.com)
  - After installing, pull a model: `ollama pull llama3.2`
- Windows is the primary tested platform (voice uses `pywin32`/SAPI as a TTS fallback).
  Mac/Linux users can run the frontend fine; the Python voice backend will need minor
  edits since it currently assumes Windows-style TTS fallback.

---

## 1. Install frontend dependencies

```bash
npm install
```

## 2. Install Python dependencies

It's strongly recommended to use a virtual environment:

```bash
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # Mac/Linux

pip install -r requirements.txt
```

> **Note on PyAudio:** on Windows, `pip install pyaudio` sometimes fails to build.
> If it does, install a prebuilt wheel instead:
> `pip install pipwin && pipwin install pyaudio`

## 3. Set your location for the weather widget

Open `src/components/WeatherWidget.tsx` and edit these two lines near the top:

```ts
const LAT = 34.0522;
const LON = -118.2437;
const LOCATION_LABEL = "LOS ANGELES, CA";
```

Replace with your own latitude/longitude (search "[your city] latitude longitude" to
find these easily) and a label to display.

## 4. Make sure Ollama is running

```bash
ollama serve
```

(If you installed Ollama as a desktop app, it likely already runs in the background —
check for it in your system tray.)

## 5. Build and launch

```bash
npm run build
npm start
```

The first launch will automatically download the Vosk speech recognition model
(~128MB) — this only happens once.

Say **"Jarvis"** and wait for the HUD's arc reactor to flash, then ask a question or
say a command like "what time is it."

---

## Development mode (hot reload)

For active development, instead of `npm start`, run:

```bash
npm run electron:dev
```

This runs the Vite dev server and Electron together with hot module reload for the
frontend. You'll still need `jarvis.py` running separately in another terminal:

```bash
venv\Scripts\python.exe jarvis.py
```

---

## Project structure

```
├── electron.cjs           # Electron main process — window creation, spawns jarvis.py
├── preload.cjs             # Secure IPC bridge between renderer and main process
├── jarvis.py                # Python voice backend — wake word, speech recognition, AI, TTS
├── requirements.txt         # Python dependencies
├── src/
│   ├── main.tsx              # React entry point
│   ├── index.css             # Global styles (transparent background for Electron)
│   └── components/
│       ├── ArcReactor.tsx     # Main HUD component — layout, WebSocket connection
│       ├── ArcReactor.css     # All HUD visual styling
│       ├── DraggableWidget.tsx # Drag-and-drop wrapper with magnetic snapping
│       ├── WidgetContext.tsx   # Tracks widget positions for snap-to-edge behavior
│       ├── WeatherWidget.tsx   # Live weather via Open-Meteo
│       ├── TimeWidget.tsx      # Clock/date display
│       ├── JarvisConsole.tsx   # Live transcript/response display
│       └── ContextMenu.tsx     # Right-click show/hide widget menu
```

---

## How the voice pipeline works

1. **`mic_thread`** continuously reads raw audio from your microphone.
2. **`recognition_thread`** feeds that audio into [Vosk](https://alphacephei.com/vosk/)
   (offline speech recognition) and watches for the word "Jarvis."
3. Once detected, the following command is either matched against simple built-in
   commands (time, date, greetings) or, if nothing matches, sent to your local
   **Ollama** model for a generated response.
4. The response is converted to speech via `edge-tts` (natural-sounding, requires
   internet for the TTS voice itself) with a fallback to Windows' built-in SAPI voice
   if `edge-tts` isn't available or fails.
5. Everything — status updates, live transcripts, and spoken responses — is pushed to
   the HUD frontend in real time over a local WebSocket (`ws://localhost:8765`).

---

## Customizing

- **Widget positions** are saved to `localStorage` per-widget, so dragging a widget
  remembers its position between launches.
- **Adding a new widget**: create a new component following the pattern in
  `WeatherWidget.tsx` or `TimeWidget.tsx`, then wire it into `ArcReactor.tsx` the same
  way the existing widgets are wired in (add to `WidgetId`, `DEFAULT_VISIBILITY`,
  `WIDGET_LABELS`, `defaultPositions()`, and the render block).
- **Adding new voice commands**: add a new trigger-phrase list and a matching `if`
  block near the top of `handle_command()` in `jarvis.py`, following the pattern of
  `_TIME_TRIGGERS`/`_DATE_TRIGGERS`.
- **Changing the wake word**: edit `WAKE_WORD` and `_WAKE_PHRASES` in `jarvis.py`.

---

## Troubleshooting

**"Electron not found" / npx prompts to install a new Electron version every launch**
Run `npm install` — this ensures the project's own pinned Electron version (from
`package.json`) is installed locally instead of falling back to a fresh download.

**HUD shows "SENSOR OFFLINE" on the weather widget**
Check your internet connection — the weather widget calls the free Open-Meteo API
directly from the browser and needs network access.

**Jarvis Console shows "OFFLINE" and never connects**
Make sure `jarvis.py` is actually running (check the terminal for
`[WS] WebSocket server -> ws://localhost:8765`). If it's not starting, check that all
Python dependencies installed correctly and that you're using the virtual environment
where you installed them.

**AI responses say "I can't reach my brain"**
Ollama isn't running, or the model hasn't been pulled. Run `ollama serve` and
`ollama pull llama3.2` (or update `OLLAMA_MODEL` in `jarvis.py` to whatever model
you've pulled instead).

---

## License

This project is released open source for anyone to use, modify, and build on. No
warranty is provided — this was built as a personal passion project and shared as-is.
Attribution appreciated but not required.
