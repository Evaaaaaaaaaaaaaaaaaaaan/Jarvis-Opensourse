interface JarvisConsoleProps {
  status: string;
  transcript: string;
  response: string;
  connected: boolean;
}

export function JarvisConsole({ status, transcript, response, connected }: JarvisConsoleProps) {
  return (
    <div className="w-jarvis-console">
      <div className="w-header">
        <span className="w-label">JARVIS LINK</span>
        <span className={`w-jc-dot ${connected ? "w-jc-dot--on" : "w-jc-dot--off"}`} />
      </div>

      <div className="w-jc-status">
        {connected ? status.toUpperCase() : "OFFLINE"}
      </div>

      {transcript && (
        <div className="w-jc-row">
          <span className="w-jc-tag">YOU</span>
          <span className="w-jc-text">{transcript}</span>
        </div>
      )}

      {response && (
        <div className="w-jc-row">
          <span className="w-jc-tag">JARVIS</span>
          <span className="w-jc-text">{response}</span>
        </div>
      )}

      {!transcript && !response && (
        <div className="w-idle">Say "Jarvis" to begin.</div>
      )}
    </div>
  );
}
